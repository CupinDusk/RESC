# Conditional planned auditor and certified timing audit v11

Standing-authorized own minimal proof/code/aggregate update; MANIFEST.json
is the input allowlist. No manuscript, private acquisition/kernel/overlay,
server/credentials or third-party raw CSV. All earlier inputs and unfavorable
results/README records remain. No new license grant.

Before loading observation endpoints, plan each ranking from slots and R.
The previously proved factor C_R=1 authorizes marginal-only decisions for
every rectangle. For other rankings the reference auditor uses beta_R as
a rejection gate, C_R*beta_R as a sufficient-admission gate, and falls back
to the standard exact difference graph in between. This is a reference
workflow for conditional auditing, not a newly adopted archive or solver.

All 89*720*6=384480 fixed-budget questions are retained. Every gate agrees
with an independently checked original zero-bias witness or outward/integer
graph certificate, with no unresolved case. Plan counts, every budget,
fallbacks and all exact outcomes are retained. A universal factor4 routing
comparison is supplied; dependent branch counts do not measure runtime,
memory, physical timing validity, deployment adoption or improved choices.

Fresh extraction, Python3.12/NumPy2.3.5/SciPy1.16.3:

    python -B -X utf8 run_checks.py --scipy-path /absolute/scipy/module/path

All prior numerical/matching/integer-certificate checks run. The complete
generated routing CSV is regenerated with an exact expected hash, not
bundled. All fixed plans use only ranking/slots before observations load.
At beta=0, exact decimal isotonic values give a zero-bias original-variable
witness; other decisions use outward log bounds and integer cycles or
potentials. Boundaries remain fallbacks unless certified. No new GPU data,
physical bias budget or command-granularity validation is established.

The unchanged optional --fetch-ordersage stage is not repeated in this
release; historical independently refetched negative records remain.
Generic matching, graph feasibility, LP and isotonic machinery are prior.
Codex assisted code, protocol, analyses and documentation.
