# Retained Hopper numerical corpus and conditional order audit, v2

This minimal same-scope update is authorized by the human's standing reply “都授权，不再询问。” It adds secondary mathematical/optimization analysis to the already public numerical v1 corpus. No new GPU measurement is included. There is no kernel/raw acquisition source, manuscript, account/server material or credentials. The exact input manifest bounds the contents. The nested v1 files remain byte-exact; their preparation-time “not publicly archived” wording is historical and superseded by the external publication notes.

Use a fresh extraction with Python3.12, NumPy2.3.5 and SciPy1.16.3:

    python -B -X utf8 run_checks.py

If SciPy is in a separate local module directory, supply `--scipy-path /absolute/path`. No download or installation is performed by this runner. The runner verifies all input hashes, reruns the original numerical fits/choices in a new generated folder, compares all retained results with floating tolerance, then runs the new conditional audit and compares its complete expected report. It writes logs and results locally. No GPU, compiler, network, account or original repository is used.

The fixed source order is floor0, peer pull1, push store2, bulk push3, global4, async store5, flat pull6. For one cell the audit writes log(observed summary)=theta_arm+b_position, with adjacent bias differences bounded by a supplied delta. This is an UNVALIDATED sensitivity restriction per adjacent arm position, not wall-clock time, measured clock/temperature drift, or arbitrary path-by-state carryover. Every reported bound is conditional on that model. With no drift bound, any arm can be made best; narrow within-arm ranges do not identify a same-state ranking.

Point min/mean/max/primary models and an artificial independent observed-summary min/max rectangle are reported separately. The rectangle is neither paired repetition data, a confidence interval, nor future coverage. The audit derives sharp pair, fixed-choice regret and possible/guaranteed-winner bounds, including exactly zero self contrast. A descriptive minimax audit uses every within-cell measured arm; it is not a heldout selector, acquisition saving or independently validated policy.

Independent HiGHS linear programs check5,340 pair supports and1,068 possible-winner feasibility instances at delta=log1.02, with zero disagreement. The full declared grid is adjacent multiplicative drift0,0.5%,1%,2%,5%,10%; none is estimated as true. Expected reports retain all89 configured cells,623 arm summaries, all35 frozen retrospective choices (19 admitted/16 unsupported), unfavorable cases and all model/grid outputs. The17/19 original agreement and all-case regret1.08267879 remain retrospective facts, not a new prospective test. Original fixed-order acquisition and post-inspection policy design are UNRESOLVED.

The mathematical note supplies proofs and exact assumptions. It credits the established minmax-regret/support-function approach; the audit does not establish a new general robust optimization framework or detect actual ordering bias. Reproduction means numerical/method checks only, not native acquisition, assembly verification, causal loop attribution, calibrated uncertainty, application benefit or cross-device validation.

New code/analysis/documentation were prepared with Codex assistance. Applicable repository terms remain in force; no new license grant is asserted. Publication is performed separately after fresh local verification under the existing authorization.
