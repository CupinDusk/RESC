# Retained Hopper numbers and matched bias-model audit v3

This is a standing-authorized same-scope minimal numerical/method update. Its18-input manifest contains only the already public numeric corpus, research scripts, protocols, expected reports and methods notes. There is no new GPU measurement, manuscript, private acquisition source, server material, account data or credentials. Earlier archives remain unchanged; nested v1 files retain their historical wording/bytes.

In a fresh extraction with Python3.12, NumPy2.3.5 and SciPy1.16.3:

    python -B -X utf8 run_checks.py

Optionally pass `--scipy-path /absolute/local/module/directory`. The runner verifies every input hash, recomputes original fitted choices in a new folder, reruns the earlier conditional order audit, then reruns the matched-model comparison and compares every expected field with declared floating tolerance. No network, device, compiler, download or installation is used.

The new comparison keeps min/max summary rectangles, budget grid and EXACT zero self contrasts fixed. An independent-marginal relaxation has the SAME position-wise ranges [-j*delta,j*delta] as the anchored shared path while forgetting its correlation. A common linear slope is a subset of that path: all pair supports and fixed-choice regrets are identical, but possible-winner sets may differ because one slope must satisfy every rival simultaneously. A bounded arm-specific residual explicitly tests a violation of the path-only structure. All assumptions remain uncalibrated mathematical sensitivity restrictions.

At assumed adjacent2%, shared/marginal unique winners are55/31 across89 and20/9 across35 C8 cells. Linear/path possible sets differ in4 cells at2% and40 at10%, despite identical regrets. Adding a residual upper budget2% at adjacent2% leaves39/89 unique winners. The reports retain all89 cells, all35 original retrospective choices, all budgets/models, limiting rivals, radii and controlled mathematical negative fixtures. They do not give workload prevalence or empirical coverage of either uncertainty model.

The new independent LPs check8010 pair supports and1602 simultaneous winner systems across linear, marginal and path-plus-residual sets, with zero disagreement. Earlier5340/1068 checks are separately rerun. Controlled mathematical fixtures and LP agreement are not hardware model-fit evidence. Narrow within-arm summaries cannot validate order/carryover restrictions. Original fixed order, missing per-arm state and post-inspection policy design remain unresolved; no causal loop effect, corrected GPU cost or prospective selector is established.

See analysis/HOPPER_R5_MODEL_ARGUMENT.md for derivations, full worked cases, complete target/units and honest primary-literature retrieval levels. Concepts of regret, possible/necessary optimality and measurement-order bias are established background; the methods note does not claim a new general robust-optimization principle. Codex assisted new arguments/code/docs. Existing repository terms apply; no new license grant is asserted.
