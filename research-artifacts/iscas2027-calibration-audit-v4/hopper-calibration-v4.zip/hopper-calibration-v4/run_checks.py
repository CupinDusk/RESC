"""Recompute the old frozen choices and new conditional order audit."""
from pathlib import Path
import argparse,hashlib,json,math,os,shutil,subprocess,sys
HERE=Path(__file__).resolve().parent
def compare(a,b,path='root'):
    if type(b) is float:assert type(a) in [int,float] and math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-12),path
    elif isinstance(b,dict):
        assert isinstance(a,dict) and set(a)==set(b),path
        for k in b:compare(a[k],b[k],path+'.'+k)
    elif isinstance(b,list):
        assert isinstance(a,list) and len(a)==len(b),path
        for i,(x,y) in enumerate(zip(a,b)):compare(x,y,path+'['+str(i)+']')
    else:assert a==b,path
def main():
    p=argparse.ArgumentParser();p.add_argument('--scipy-path');p.add_argument('--fetch-ordersage',action='store_true');a=p.parse_args()
    m=json.loads((HERE/'MANIFEST.json').read_text(encoding='utf-8'))
    for n,h in m['files'].items():assert hashlib.sha256((HERE/n).read_bytes()).hexdigest()==h,n
    env=os.environ.copy()
    if a.scipy_path:env['PYTHONPATH']=a.scipy_path+os.pathsep+env.get('PYTHONPATH','')
    generated=HERE/'generated/reanalysis';assert not generated.exists(),'Use a fresh extraction';generated.mkdir(parents=True)
    old=HERE/'artifacts/hopper-retained-v1'
    for f in old.iterdir():
        if f.is_file():shutil.copyfile(f,generated/f.name)
    run=subprocess.run([sys.executable,'-B','-X','utf8',str(generated/'reanalyze.py')],env=env,capture_output=True,text=True,timeout=120)
    (HERE/'generated/reanalysis.log').write_text(run.stdout+'\n'+run.stderr,encoding='utf-8');assert run.returncode==0,run.stderr
    compare(json.loads((generated/'recomputed-results.json').read_text(encoding='utf-8')),json.loads((old/'recomputed-results.json').read_text(encoding='utf-8')))
    run=subprocess.run([sys.executable,'-B','-X','utf8',str(HERE/'analysis/hopper_order_sensitivity.py')],env=env,capture_output=True,text=True,timeout=240)
    (HERE/'generated/order-audit.log').write_text(run.stdout+'\n'+run.stderr,encoding='utf-8');assert run.returncode==0,run.stderr
    actual=json.loads((HERE/'analysis/HOPPER_ORDER_SENSITIVITY_RESULTS.json').read_text(encoding='utf-8'))
    expected=json.loads((HERE/'expected/HOPPER_ORDER_SENSITIVITY_RESULTS.json').read_text(encoding='utf-8'));compare(actual,expected)
    run=subprocess.run([sys.executable,'-B','-X','utf8',str(HERE/'analysis/hopper_model_comparison.py')],env=env,capture_output=True,text=True,timeout=240)
    (HERE/'generated/model-comparison.log').write_text(run.stdout+'\n'+run.stderr,encoding='utf-8');assert run.returncode==0,run.stderr
    model_actual=json.loads((HERE/'analysis/HOPPER_R5_MODEL_RESULTS.json').read_text(encoding='utf-8'))
    model_expected=json.loads((HERE/'expected/HOPPER_R5_MODEL_RESULTS.json').read_text(encoding='utf-8'));compare(model_actual,model_expected)
    run=subprocess.run([sys.executable,'-B','-X','utf8',str(HERE/'analysis/hopper_anchor_audit.py')],env=env,capture_output=True,text=True,timeout=240)
    (HERE/'generated/anchor-audit.log').write_text(run.stdout+'\n'+run.stderr,encoding='utf-8');assert run.returncode==0,run.stderr
    anchor_actual=json.loads((HERE/'analysis/HOPPER_R6_ANCHOR_RESULTS.json').read_text(encoding='utf-8'))
    compare(anchor_actual,json.loads((HERE/'expected/HOPPER_R6_ANCHOR_RESULTS.json').read_text(encoding='utf-8')))
    external='NOT_RUN_REQUIRES_EXPLICIT_FETCH_FLAG'
    if a.fetch_ordersage:
        run=subprocess.run([sys.executable,'-B','-X','utf8',str(HERE/'analysis/fetch_ordersage_schemas.py')],env=env,capture_output=True,text=True,timeout=300)
        (HERE/'generated/external-fetch.log').write_text(run.stdout+'\n'+run.stderr,encoding='utf-8');assert run.returncode==0,run.stderr
        compare(json.loads((HERE/'analysis/external-ordersage-inputs/MANIFEST.json').read_text(encoding='utf-8')),json.loads((HERE/'expected/ORDERSAGE_INPUT_MANIFEST.json').read_text(encoding='utf-8')))
        run=subprocess.run([sys.executable,'-B','-X','utf8',str(HERE/'analysis/ordersage_secondary.py')],env=env,capture_output=True,text=True,timeout=120)
        (HERE/'generated/external-assessment.log').write_text(run.stdout+'\n'+run.stderr,encoding='utf-8');assert run.returncode==0,run.stderr
        compare(json.loads((HERE/'analysis/ORDERSAGE_SECONDARY_RESULTS.json').read_text(encoding='utf-8')),json.loads((HERE/'expected/ORDERSAGE_SECONDARY_RESULTS.json').read_text(encoding='utf-8')))
        external='PASS_PUBLISHED_INPUTS_AND_ALL_FROZEN_ASSESSMENT_RESULTS'
    result={'result':'PASS_RETAINED_NUMBERS_REANCHORING_AND_OPTIONAL_EXTERNAL_ASSESSMENT','input_files_verified':len(m['files']),
        'old_numeric_reanalysis':'PASS','new_conditional_audit':'PASS','checks':actual['checks'],'new_native_measurements':0,
        'matched_model_comparison':'PASS','new_model_checks':model_actual['checks'],'candidate_centered_anchor_audit':anchor_actual['checks'],'ordersage_secondary_assessment':external,'drift_bound_calibrated':False,'untouched_policy_test':False,'public_release_performed_by_runner':False}
    (HERE/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result))
if __name__=='__main__':main()
