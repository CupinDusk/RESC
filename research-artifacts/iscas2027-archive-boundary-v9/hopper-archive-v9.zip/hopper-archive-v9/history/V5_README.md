# Joint timing-query and calibration-reference artifact v5

Same-scope public update under standing human authorization. This contains our previously public retained numeric matrix, own code/protocols, proofs and derived aggregate outputs. It contains no manuscript, private acquisition/kernel/overlay code, server material, credentials, upstream raw CSVs or OrderSage launch/reset code. No new license grant is asserted. The earlier v4 README is preserved under history; its phrase all considered queries applies to candidate-wise ranking/regret queries, not the new shared-trajectory conjunctions.

Fresh extraction, Python3.12, NumPy2.3.5, SciPy1.16.3:

    python -B -X utf8 run_checks.py --scipy-path /absolute/scipy/module/path

The offline stages rerun all prior numeric/model/anchor checks and all96120 new conjunction cases, independently checking all16020 original path LPs and18 median-box LPs at log1.02. An explicit fetch option downloads ONLY six pinned public numerical CSVs, verifies their blobs/hashes, and reruns the chronological assessment, all10000-replication stationary controls and all five dependent cyclic splits:

    python -B -X utf8 run_checks.py --fetch-ordersage

No remote experiment or source launcher is executed. Upstream data redistribution terms were not located, so raw CSVs are generated local inputs only. Expected aggregate reports omit the full50-query point-value listing, retaining just two worked examples; the complete listing is generated from pinned inputs. The full96120-query CSV is likewise generated and checked by its SHA256, not bundled as an input.

Read analysis/HOPPER_R7_METHOD.md and HOPPER_R7_JOINT_ARGUMENT.md. Candidate-centered boxes remain EXACT for each candidate's winner-star/regret query. They can fail for two disjoint comparisons sharing ONE nuisance path; the new theorem gives the exact negative-cycle test and a region where EVERY real-anchor box admits a path-infeasible conjunction. This specializes established DBM closure rather than inventing general graph algorithms. Old grid no-anchor-recovery counts0/2/11/18/102/286 are conditional dependent cases, not hardware rank errors or workload prevalence.

Original calibration failures remain. Stationary no-order controls quantify ordinary finite maxima and reuse of center-fitting data; they do not identify a causal ordering effect or statistically explain actual data. All five cyclic sensitivities remain, with no preferred replacement split. The50 matched uFS queries retain naive agreement50, path/centered certificates10 and abstentions40; no improved choice or same-state truth claim is made. None of these CPU/filesystem or synthetic references calibrates H20. No new GPU measurements, physical bias bound or untouched policy test is supplied. Codex assisted research arguments, code, analysis and documentation.
