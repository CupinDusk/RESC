# Anchoring and calibration audit v4

This standing-authorized same-scope update contains our already public numeric corpus, our research code/protocols, provenance hashes and derived aggregate reports. It includes NO manuscript, private kernel/acquisition source, server file, credential, third-party CSV or upstream experiment/reset code. Previous packages/reviews are immutable history.

Fresh extraction with Python3.12, NumPy2.3.5 and SciPy1.16.3:

    python -B -X utf8 run_checks.py

This runs all three prior numeric/model stages and the new candidate-centered anchor audit offline. Optionally specify --scipy-path /absolute/module/path. To reproduce the external published-data assessment, explicitly allow the six pinned public CSV downloads:

    python -B -X utf8 run_checks.py --fetch-ordersage

Use a fresh extraction for each run. The explicit fetch stage verifies exact Git blobs/SHA256 at pinned OrderSage commit aed526a5a86432834b881bf0166a34f6ffe57623. Its raw files remain local generated inputs. No OrderSage controller/worker/launcher/config/reset code is downloaded or executed. An upstream data redistribution license has not been located, so third-party raw data are not bundled. The protocol and complete numerical reports are ours. Existing terms/notices remain in force; no new license grant is asserted.

IMPORTANT CORRECTION OF COMPARATOR INTERPRETATION: floor0 box55-versus31 is not coordinate invariant and is not intrinsic path superiority over interval audits. Boxes reanchored separately at each candidate reproduce every path pair-support/regret/possible/necessary/unique-minimizer output considered here. They are different candidate-dependent sets, not one common box equal to the path. Original reports/wording are retained as historical inputs; the current interpretation is analysis/HOPPER_R6_METHOD.md. New2670 pair LPs and534 joint winner systems check this stronger comparator. The common-anchor0..6 grid and worked counterexample are retained.

The external secondary split is fixed before numerical result inspection after known published aggregates and schema/category inspection. All1300 measured rows/3 published case studies remain. Randomized calibration maxima fail on heldout randomized episodes in every corpus. The50 matched uFS comparisons have naive agreement50, path/centered certificates10 and abstentions40, floor0-box abstentions50. The audit does NOT improve choices on this corpus. No outcome-driven refit/multiplier/split is used. Negative results are scientific findings, not reproduction failures.

Budgets absorb noise, center-estimation error and carryover; neither frozen center is same-state truth. No statistical/future coverage or exchangeability guarantee is claimed. These public CPU/filesystem measurements do not calibrate Hopper or provide new GPU measurements. Original H20 fixed order, missing per-arm state and retrospective selector design remain unresolved. The raw-row provenance note is a local archival check, not a newly reproduced raw acquisition in this package. See the full method note for literature retrieval levels and all evidence boundaries. Codex assisted research arguments, code, analysis and documentation.
