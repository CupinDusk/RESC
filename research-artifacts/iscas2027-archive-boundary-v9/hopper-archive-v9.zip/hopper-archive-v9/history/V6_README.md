# Minimum explanation radius and sharp slot-factor artifact v6

Standing-authorized same-scope public update: own previously public numeric matrix, code, proofs, protocols and derived aggregate outputs. No manuscript/private acquisition/kernel/overlay/server/credential material, upstream raw CSV, or reset/launch code. No new license grant. v4/v5 README files and all old expected reports remain immutable history.

CORRECTION: the v5/R7 median-anchor inequality is true but automatic under passing disjoint individual path tests. It is not an extra condition or independent contribution. All old numeric outcomes remain. Read analysis/HOPPER_R8_METHOD.md and HOPPER_R8_RADIUS_ARGUMENT.md for this correction and the new, nonredundant quantitative statement.

The inverse-budget query asks the minimum adjacent-position budget for ONE shared joint ranking explanation. Its exact radius can exceed the strongest lower bound from EVERY independent reanchored-box feasibility answer by the tight factor N-2 for slots1..N. The positive-width controlled family reaches this bound; there is no slot-span-independent constant. These claims concern the specific box relaxation/query family, not all interval algorithms or a new general inverse-optimization/DBM method.

Fresh extraction, Python3.12, NumPy2.3.5, SciPy1.16.3:

    python -B -X utf8 run_checks.py --scipy-path /absolute/scipy/module/path

Offline stages reproduce all prior checks plus all16020 retained radii, all1166 positive windows,18 minimum-radius LPs,3498 boundary/midpoint LPs and5396 controlled LPs. Full query/radius CSVs are generated and checked by SHA256. Optimum LP witnesses are not unique: expected comparisons ignore their chosen vertex while checking all optimum values/categories; the script/solver checks feasibility.

    python -B -X utf8 run_checks.py --fetch-ordersage

This optional explicit stage re-fetches only six pinned public numerical CSVs, checks Git blobs, and reruns unchanged secondary assessments and stationary/cyclic references. No upstream launcher/reset code or remote experiment is executed. Upstream raw data are not bundled. All original failed calibration/negative choice results remain; no favorable split replaces the chronological primary table.

Continuous windows occur somewhere in all89 cells, but this includes large hypothetical budgets and is not an operating-point prevalence claim. Old fraction grid0/.005/.01/.02/.05/.10 affects0/2/8/14/48/82 cells,0/2/11/18/102/286 dependent queries. The maximum radius ratio3.874709 has its upper radius beyond the old10% fraction grid and is explicitly labeled. No physical H20 bias bound, same-state truth, new GPU measurements, causal ordering effect, improved choices or untouched predictor test is supplied. Codex assisted arguments, code, analysis and documentation.
